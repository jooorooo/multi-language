<?php namespace Dimsav\Translatable\Test\Model;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * A test class used as a normal class extending Eloquent, not using laravel-translatable.
 */
class Company extends Eloquent
{
}
