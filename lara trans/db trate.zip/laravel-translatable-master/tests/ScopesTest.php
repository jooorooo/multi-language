<?php

use Dimsav\Translatable\Test\Model\Country;
use Dimsav\Translatable\Test\Model\CountryStrict;
use Dimsav\Translatable\Test\Model\CountryWithCustomLocaleKey;

class ScopesTest extends TestsBase
{
    public function test_translated_in_scope_returns_only_translated_records_for_this_locale()
    {
        $translatedCountries = Country::translatedIn('fr')->get();
        $this->assertEquals($translatedCountries->count(), 1);
    }

    public function test_translated_in_scope_works_with_default_locale()
    {
        App::setLocale('de');
        $translatedCountries = Country::translatedIn()->get();

        $this->assertSame($translatedCountries->count(), 1);
        $this->assertSame('Griechenland', $translatedCountries->first()->name);
    }

    public function test_translated_scope_returns_records_with_at_least_one_translation()
    {
        $translatedCountries = Country::translated()->get();
        $this->assertEquals($translatedCountries->count(), 2);
    }

    public function test_lists_of_translated_fields()
    {
        App::setLocale('de');
        $list = [[
            'id' => '1',
            'name' => 'Griechenland',
        ]];
        $this->assertEquals($list, Country::listsTranslations('name')->get()->toArray());
    }

    public function test_lists_of_translated_fields_with_fallback()
    {
        App::make('config')->set('translatable.fallback_locale', 'en');
        App::setLocale('de');
        $country = new Country();
        $country->useTranslationFallback = true;
        $list = [[
            'id' => '1',
            'name' => 'Griechenland',
        ],[
            'id' => '2',
            'name' => 'France',
        ]];
        $this->assertEquals($list, $country->listsTranslations('name')->get()->toArray());
    }

    public function test_scope_withTranslation_without_fallback()
    {
        $result = Country::withTranslation()->first();
        $loadedTranslations = $result->toArray()['translations'];
        $this->assertCount(1, $loadedTranslations);
        $this->assertSame('Greece', $loadedTranslations[0]['name']);
    }

    public function test_scope_withTranslation_with_fallback()
    {
        App::make('config')->set('translatable.fallback_locale', 'de');
        App::make('config')->set('translatable.use_fallback', true);

        $result = Country::withTranslation()->first();
        $loadedTranslations = $result->toArray()['translations'];
        $this->assertCount(2, $loadedTranslations);
        $this->assertSame('Greece', $loadedTranslations[0]['name']);
        $this->assertSame('Griechenland', $loadedTranslations[1]['name']);
    }

    public function test_whereTranslation_filters_by_translation()
    {
        /** @var Country $country */
        $country = Country::whereTranslation('name', 'Greece')->first();
        $this->assertSame('gr', $country->code);
    }

    public function test_whereTranslation_filters_by_translation_and_locale()
    {
        Country::create(['code' => 'some-code', 'name' => 'Griechenland']);

        /** @var Country $country */
        $this->assertSame(2, Country::whereTranslation('name', 'Griechenland')->count());

        $result = Country::whereTranslation('name', 'Griechenland', 'de')->get();
        $this->assertSame(1, $result->count());
        $this->assertSame('gr', $result->first()->code);
    }
}
