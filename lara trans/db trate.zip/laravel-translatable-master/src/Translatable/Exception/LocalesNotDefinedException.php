<?php namespace Dimsav\Translatable\Exception;

class LocalesNotDefinedException extends \Exception
{
}
